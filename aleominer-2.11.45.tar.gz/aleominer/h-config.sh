#!/usr/bin/env bash

source h-manifest.conf

[[ "$CUSTOM_URL" = "" ]] && echo "Using default CUSTOM_URL" && CUSTOM_URL="stratum+ssl://nlb-gnbhhkqxxdgt9wc6ou.cn-chengdu.nlb.aliyuncs.com:4420"
if echo "$CUSTOM_USER_CONFIG"|grep NONCE_TIMES;then
    CUSTOM_NONCE_TIMES=$(echo "$CUSTOM_USER_CONFIG" |head -1)
fi

conf=""
conf+="ACCOUNT=\"$CUSTOM_TEMPLATE\""$'\n'
conf+="CUSTOM_URL=\"$CUSTOM_URL\""$'\n'
conf+="CUSTOM_NONCE_TIMES=\"$CUSTOM_NONCE_TIMES\""$'\n'

echo "$conf" > $CUSTOM_CONFIG_FILENAME